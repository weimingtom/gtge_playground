package com.ugame.twilight.handlers;

import java.io.File;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorRegistry;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PartInitException;

import com.ugame.twilight.editor.PathEditorInput;

public class OpenViewAction extends Action implements IWorkbenchWindowActionDelegate {
	private final static String EDITOR_ID = 
		"com.ugame.twilight.editor.simpleEditor";
	
	private IWorkbenchWindow fWindow;

	public OpenViewAction() {
		setEnabled(true);
	}

	@Override
	public void init(IWorkbenchWindow window) {
		// TODO Auto-generated method stub
		fWindow = window;
	}
	
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		fWindow = null;
	}

	@Override
	public void run(IAction action) {
		// TODO Auto-generated method stub
		run();
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void run() {
		System.out.println("OpenViewAction:run()");
		File file = queryFile();
		if (file != null) {
			IEditorInput input = createEditorInput(file);
			String editorId = getEditorId(file);
			IWorkbenchPage page = fWindow.getActivePage();
			try {
				page.openEditor(input, editorId);
			} catch (PartInitException e) {
				e.printStackTrace();
			}
		} else {
			/*
			MessageDialog.openWarning(fWindow.getShell(),
					"Problem", "File is 'null'");
			*/
		}
	}
	
	private File queryFile() {
		FileDialog dialog = new FileDialog(fWindow.getShell(), SWT.OPEN);
		dialog.setText("打开脚本文件");
		String path = dialog.open();
		if (path != null && path.length() > 0)
			return new File(path);
		return null;
	}
	
	private String getEditorId(File file) {
		IWorkbench workbench = fWindow.getWorkbench();
		IEditorRegistry editorRegistry = workbench.getEditorRegistry();
		IEditorDescriptor descriptor = editorRegistry.getDefaultEditor(file
				.getName());
		if (descriptor != null)
			return descriptor.getId();
		return EDITOR_ID;
	}

	private IEditorInput createEditorInput(File file) {
		IPath location = new Path(file.getAbsolutePath());
		PathEditorInput input = new PathEditorInput(location);
		return input;
	}
}
