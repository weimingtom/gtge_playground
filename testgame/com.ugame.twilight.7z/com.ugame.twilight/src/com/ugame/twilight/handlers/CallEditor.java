package com.ugame.twilight.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.handlers.HandlerUtil;

import com.ugame.twilight.editor.MyPersonEditor;
import com.ugame.twilight.editor.MyPersonEditorInput;
import com.ugame.twilight.model.Person;
import com.ugame.twilight.views.View;

public class CallEditor extends AbstractHandler {
	public final static String COMMAND_ID = "com.ugame.twilight.command1"; 
	
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		System.out.println("called");
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindow(event);
		IWorkbenchPage page = window.getActivePage();
		View view = (View) page.findView(View.ID);
		ISelection selection = view.getSite().getSelectionProvider()
				.getSelection();
		if (selection != null && selection instanceof IStructuredSelection) {
			Object obj = ((IStructuredSelection) selection).getFirstElement();
			if (obj != null) {
				Person person = (Person) obj;
				MyPersonEditorInput input = new MyPersonEditorInput(
						person.getId());
				try {
					page.openEditor(input, MyPersonEditor.ID);
				} catch (PartInitException e) {
					throw new RuntimeException(e);
				}
			}
		}
		return null;
	}
}