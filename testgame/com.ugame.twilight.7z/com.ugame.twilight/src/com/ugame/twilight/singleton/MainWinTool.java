package com.ugame.twilight.singleton;

import org.eclipse.ui.application.IWorkbenchWindowConfigurer;

public enum MainWinTool {
	INSTANCE;
	
	public void init(IWorkbenchWindowConfigurer configurer) {
		//configurer.setInitialSize(new Point(800, 600));
		configurer.setShowCoolBar(true);
		configurer.setShowStatusLine(true);
		configurer.setShowPerspectiveBar(true);
		
		//configurer.setShowProgressIndicator(true);
		configurer.setShowMenuBar(true);
	}
	
	public void dispose() {
		
	}
}
