package com.ugame.twilight.singleton;


import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;

public enum StatuslineTool {
	INSTANCE;
	
	public void init(IWorkbenchWindowConfigurer configurer) {
		IStatusLineManager manager = configurer.getActionBarConfigurer().getStatusLineManager();
		manager.setMessage(null, "Status line is ready");
	}
	
	public void dispose() {
		
	}
}
