package com.ugame.twilight.gtge;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.golden.gamedev.Game;
import com.golden.gamedev.GameLoader;
import com.golden.gamedev.object.AnimatedSprite;

public class MyGame extends Game {
	private static MyGame INSTANCE = null;
	
	public static synchronized MyGame getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new MyGame();
		}
		return INSTANCE;
	}
	
	private AnimatedSprite bgSprite;
	private AnimatedSprite fgSprite;

	private MyGame() {
		
	}
    
    @Override
    public void initResources() {
    	//sprite = new Sprite(getImage("images/bg01a.png"), 0, 0);
    	BufferedImage[] bgImages = new BufferedImage[] {
    			getImage("images/bg01a.png"),
    			getImage("images/bg02a.png"),
    			getImage("images/bg02d.png"),
    	};
    	bgSprite = new AnimatedSprite(bgImages, 0, 0);
    	bgSprite.setAnimate(false);
    	bgSprite.setLoopAnim(false);
    	bgSprite.setFrame(0);
    	
    	BufferedImage[] fgImages = new BufferedImage[] {
    			getImage("images/nm001.png"),
    			getImage("images/nm002.png"),
    			getImage("images/nm010.png"),
    			getImage("images/nm030.png"),
    	};
    	fgSprite = new AnimatedSprite(fgImages, 120, 0);
    	fgSprite.setAnimate(false);
    	fgSprite.setLoopAnim(false);
    	fgSprite.setFrame(0);
    }
    
    @Override
    public void update(long elapsedTime) {
    	bgSprite.update(elapsedTime);
    	fgSprite.update(elapsedTime);
    }

    public void render(Graphics2D g) {
        g.setColor(Color.BLUE);
        g.fillRect(0, 0, getWidth(), getHeight());
        bgSprite.render(g);
        fgSprite.render(g);
    }

    public String toString() {
    	return "MyGame";
    }
    
    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new MyGame(), new Dimension(640,480), false);
        game.start();
    }
}