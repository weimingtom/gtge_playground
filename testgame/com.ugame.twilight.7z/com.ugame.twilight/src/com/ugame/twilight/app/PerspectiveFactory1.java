package com.ugame.twilight.app;

import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

public class PerspectiveFactory1 implements IPerspectiveFactory {

	@Override
	public void createInitialLayout(IPageLayout layout) {
		//TODO: Fix the layout
		layout.setEditorAreaVisible(false);
		//layout.setFixed(true);
	}
}
