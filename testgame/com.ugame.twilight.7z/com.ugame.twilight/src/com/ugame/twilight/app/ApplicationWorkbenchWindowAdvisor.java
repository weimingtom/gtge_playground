package com.ugame.twilight.app;

import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

import com.ugame.twilight.singleton.MainWinTool;
import com.ugame.twilight.singleton.StatuslineTool;
import com.ugame.twilight.singleton.TrayTool;

public class ApplicationWorkbenchWindowAdvisor extends WorkbenchWindowAdvisor {

	public ApplicationWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		super(configurer);
	}

	public ActionBarAdvisor createActionBarAdvisor(
			IActionBarConfigurer configurer) {
		return new ApplicationActionBarAdvisor(configurer);
	}

	public void preWindowOpen() {
		IWorkbenchWindowConfigurer configurer = getWindowConfigurer();
		MainWinTool.INSTANCE.init(configurer);
	}
	
	@Override
	public void postWindowOpen() {
		IWorkbenchWindowConfigurer configurer = getWindowConfigurer();
		StatuslineTool.INSTANCE.init(configurer);
		TrayTool.INSTANCE.init(configurer, Activator.PLUGIN_ID);
	}
	
	@Override
	public void dispose() {
		StatuslineTool.INSTANCE.dispose();
		TrayTool.INSTANCE.dispose();
		MainWinTool.INSTANCE.dispose();
	}
}
