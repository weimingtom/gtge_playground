package com.ugame.twilight.app;

import org.eclipse.ui.IWorkbenchPreferenceConstants;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchAdvisor;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

public class ApplicationWorkbenchAdvisor extends WorkbenchAdvisor {

	private static final String PERSPECTIVE_ID = 
			//"com.ugame.twilight.perspective1";
			"com.ugame.twilight.perspective";
	
	public WorkbenchWindowAdvisor createWorkbenchWindowAdvisor(
			IWorkbenchWindowConfigurer configurer) {
		//TODO: Change Perspective Bar
		PlatformUI.getPreferenceStore().setDefault(
				IWorkbenchPreferenceConstants.DOCK_PERSPECTIVE_BAR,
				IWorkbenchPreferenceConstants.TOP_RIGHT);
		PlatformUI.getPreferenceStore().setDefault(
				IWorkbenchPreferenceConstants.SHOW_TRADITIONAL_STYLE_TABS,
				"false");
		return new ApplicationWorkbenchWindowAdvisor(configurer);
	}

	public String getInitialWindowPerspectiveId() {
		//TODO: Set default perspective
		return PERSPECTIVE_ID;
	}

}
