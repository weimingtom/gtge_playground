package com.ugame.twilight.editor.python;

import org.eclipse.core.runtime.CoreException;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.source.IAnnotationModel;

import com.ugame.twilight.editor.SimpleDocumentProvider;

public class PythonDocumentProvider extends SimpleDocumentProvider {

	@Override
    protected void setupDocument(IDocument document) {
		PyPartitionScanner.checkPartitionScanner(document);
	}

	@Override
    protected IAnnotationModel createAnnotationModel(Object element) throws CoreException {
		return null;
	}
}