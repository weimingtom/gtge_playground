package com.ugame.twilight.editor.xml;

import org.eclipse.ui.texteditor.ITextEditorExtension3;

import com.ugame.twilight.editor.ColorManager;
import com.ugame.twilight.editor.SimpleEditor;


public class XMLEditor extends SimpleEditor {

	private ColorManager colorManager;

	@Override
    protected void internal_init() {
		configureInsertMode(ITextEditorExtension3.SMART_INSERT, false);
		colorManager = new ColorManager();
		setSourceViewerConfiguration(new XMLConfiguration(colorManager));
		setDocumentProvider(new XMLDocumentProvider());
	}
	
	@Override
    public void dispose() {
		colorManager.dispose();
		super.dispose();
	}
}
