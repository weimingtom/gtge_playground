package com.ugame.twilight.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.part.ViewPart;

import com.ugame.twilight.app.Activator;

public class ViewPart2 extends ViewPart {
	private Image[] images;
	private Image[] images2;
	
	@Override
	public void createPartControl(final Composite parent) {
		// TODO Auto-generated method stub
		parent.setLayout(null);
		/*
		final CCombo combo = new CCombo(parent, SWT.READ_ONLY | SWT.BORDER);
		for (int i = 0; i < 5; i++) {
			combo.add("item" + i);
		}
		combo.setText("item0");
		combo.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				System.out.println("Item selected");
			};
		});
		combo.setLocation(0, 0);
		combo.setSize(200, 20);
		*/
		
		//---------------------------------	
		//Display.getCurrent().getSystemImage(SWT.ICON_QUESTION);
		Display display = Display.getCurrent();
		Class cls = this.getClass();
		images = new Image[] {
				new Image(display, cls.getResourceAsStream("/images/bg01a.png")),				
				new Image(display, cls.getResourceAsStream("/images/bg02a.png")),
				new Image(display, cls.getResourceAsStream("/images/bg02d.png")),
				new Image(display, cls.getResourceAsStream("/images/nm001.png")),
				new Image(display, cls.getResourceAsStream("/images/nm002.png")),
				new Image(display, cls.getResourceAsStream("/images/nm010.png")),
				new Image(display, cls.getResourceAsStream("/images/nm030.png")),
		};
		images2 = new Image[images.length];
		for(int i = 0; i < images.length; i++) {
			images2[i] = new Image(display, 
					images[i].getImageData().scaledTo(35, 35));
		}
		
		final ScrolledComposite sc = new ScrolledComposite(parent, 
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		sc.setLayout(null);
		
		final Composite c = new Composite(sc, SWT.NONE);
		Listener listener = new Listener () {
			public void handleEvent (Event e) {
				Control [] children = c.getChildren ();
				for (int i=0; i<children.length; i++) {
					Control child = children [i];
					if (e.widget != child && child instanceof Button && 
							(child.getStyle () & SWT.TOGGLE) != 0) {
						((Button) child).setSelection (false);
					}
					if(e.widget == child) {
						updateThumbnail(i);
					}
				}
				((Button) e.widget).setSelection(true);
			}
		};
		int nh = (images2.length % 3 == 0) ? (images2.length / 3) : (images2.length / 3) + 1;
		for (int j = 0; j < nh; j++) {
			//System.out.println("j=="+j);
			for (int i = 0; i < 3; i++) {
				if((j * 3 + i) >= images2.length) {
					break;
				}
				//System.out.println("i=="+i);
				Button button = new Button(c, SWT.TOGGLE);
				button.setImage(images2[j * 3 + i]);
				button.addListener(SWT.Selection, listener);
				if (i == 0 && j == 0) {
					button.setSelection(true);
				}
				button.setBounds(i * 50, j * 50, 50, 50);
				button.setToolTipText("button");
			}
		}
		
		sc.setContent(c);
		sc.setExpandHorizontal(true);
		sc.setExpandVertical(true);
		sc.setMinSize(c.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		sc.setShowFocusedControl(true);
		//Rectangle rect = combo.getBounds();
		//sc.setBounds(0, rect.y + rect.height, 200, 200);
		sc.setBounds(0, 0, 200, 200);
		
		parent.addListener(SWT.Resize,  new Listener() {
			public void handleEvent (Event e) {
				Point size = parent.getSize();
				//combo.setSize(size.x, 20);
				sc.setSize(size.x, size.y - 20);
			}
		});
	}
	
	private void updateThumbnail(int i) {
		Image image = images[i];
		IWorkbenchWindow window = Activator.getDefault().getWorkbench().getActiveWorkbenchWindow();
		IWorkbenchPage page = window.getActivePage();
		ViewPart3 view = (ViewPart3) page.findView(ViewPart3.ID);
		System.out.println("updateThumbnail");
		view.updateThumbnail(image);
	}
	
	@Override
	public void setFocus() {
		
	}
}
