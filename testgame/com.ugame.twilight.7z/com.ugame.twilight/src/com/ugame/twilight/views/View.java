package com.ugame.twilight.views;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.ListViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.part.ViewPart;

import com.ugame.twilight.handlers.CallEditor;
import com.ugame.twilight.model.MyModel;
import com.ugame.twilight.model.Person;

public class View extends ViewPart {
	public static final String ID = "com.ugame.twilight.view";

	private ListViewer viewer;

	@Override
	public void createPartControl(Composite parent) {
		viewer = new ListViewer(parent);
		viewer.setContentProvider(ArrayContentProvider.getInstance());
		viewer.setLabelProvider(new LabelProvider() {
			@Override
			public String getText(Object element) {
				Person p = (Person) element;
				return p.getFirstName() + " " + p.getLastName();
			};
		});
		viewer.setInput(MyModel.getInstance().getPersons());
		getSite().setSelectionProvider(viewer);
		hookDoubleClickCommand();
	}

	private void hookDoubleClickCommand() {
		viewer.addDoubleClickListener(new IDoubleClickListener() {
			@Override
			public void doubleClick(DoubleClickEvent event) {
				IHandlerService handlerService = (IHandlerService) getSite().getService(IHandlerService.class);
				try {
					handlerService.executeCommand(CallEditor.COMMAND_ID, null);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
	}
	
	public void setFocus() {
		viewer.getControl().setFocus();
	}
}