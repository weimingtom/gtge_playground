package com.ugame.twilight.views;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;

import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import com.ugame.twilight.gtge.MyGame;
import com.ugame.twilight.gtge.SWTGameLoader;

public class ViewPart1 extends ViewPart {
	public static final String ID = "com.ugame.twilight.view1";
	
	private SWTGameLoader game;
	
	@Override
	public void createPartControl(Composite parent) {
		final ScrolledComposite sc = new ScrolledComposite(parent, 
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		sc.setLayout(null);
		
		final Composite composite = new Composite(sc, SWT.EMBEDDED);
		composite.setBounds(0, 0, 640, 480);
		sc.setContent(composite);
		
		Frame frame = SWT_AWT.new_Frame(composite);
		frame.setBackground(Color.BLACK);
		game = new SWTGameLoader(frame);
        game.setup(MyGame.getInstance(), new Dimension(640, 480), false);
        new Thread(new Runnable() {
			public void run() {
		        game.start();
			}
		}).start();     
	}

	@Override
	public void setFocus() {
		
	}
}
