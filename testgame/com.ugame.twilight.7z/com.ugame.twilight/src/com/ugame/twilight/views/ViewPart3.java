package com.ugame.twilight.views;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

public class ViewPart3 extends ViewPart {
	public static final String ID = "com.ugame.twilight.view3";
	private Canvas canvas;
	private PaintListener listener;
	private Label label;

	@Override
	public void createPartControl(Composite parent) {
		parent.setLayout(null);
		/*
		final ScrolledComposite sc = new ScrolledComposite(parent, 
				SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		sc.setLayout(null);
		*/
		
		canvas = new Canvas(parent, SWT.BORDER);
		listener = new PaintListener() {  
            public void paintControl(PaintEvent event) {
        		Image image = Display.getCurrent().getSystemImage(SWT.ICON_QUESTION);
                event.gc.drawImage(image, 0, 0);  
            }
        };
		canvas.addPaintListener(listener);
		canvas.setBounds(0, 0, 200, 200);
		
		//---------------------------------
		
		label = new Label(parent, SWT.NONE);
		label.setText("Size:0*0, Scale:100.0%");
		Rectangle rectCanvas = canvas.getBounds();
		label.setBounds(0, rectCanvas.y + rectCanvas.height, 200, 20);
	}

	public void updateThumbnail(final Image image) {
		canvas.removePaintListener(listener);
		double scale = 0;
		int w = image.getImageData().width;
		int h = image.getImageData().height;
		if(image.getImageData().width > image.getImageData().height) {
			scale = 200.0 / w; 
		} else {
			scale = 200.0 / h; 
		}
		canvas.setSize((int)(scale * w), (int)(scale * h));
		listener = new PaintListener() {  
            public void paintControl(PaintEvent event) {
            	Image scaleImage = new Image(Display.getCurrent(), 
            			image.getImageData().scaledTo(canvas.getSize().x, canvas.getSize().y));
                event.gc.drawImage(scaleImage, 0, 0);  
            }  
        };
		canvas.addPaintListener(listener);
		canvas.redraw();
		Rectangle rectCanvas = canvas.getBounds();
		label.setBounds(0, rectCanvas.y + rectCanvas.height, 200, 20);
		label.setText("Size:"+
				image.getImageData().width+
				"*"+
				image.getImageData().height+
				", Scale:"+
				Math.floor(scale * 100)+"%");
	}
	
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

}
