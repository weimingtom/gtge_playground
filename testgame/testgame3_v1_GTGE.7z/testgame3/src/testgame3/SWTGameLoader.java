package testgame3;

import java.awt.Dimension;
import java.awt.Frame;

import com.golden.gamedev.Game;
import com.golden.gamedev.GameLoader;
import com.golden.gamedev.engine.graphics.WindowExitListener;

public class SWTGameLoader extends GameLoader {
	private static final long serialVersionUID = 1L;
	protected Frame frame;
	
	public SWTGameLoader(Frame frame) {
		this.frame = frame;
	}
	
	@Override
	public void setup(Game game, Dimension d, boolean fullscreen,
			boolean bufferstrategy) {
		try {
			if (!this.validJavaVersion()) {
				System.exit(-1);
			}
			SWTMode mode = new SWTMode(d, bufferstrategy, this.frame);
			mode.getFrame().removeWindowListener(
					WindowExitListener.getInstance());
			mode.getFrame().addWindowListener(this);
			this.gfx = mode;
			this.game = game;
			this.game.bsGraphics = this.gfx;
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}
}
