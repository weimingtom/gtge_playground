package testgame3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;

import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import com.golden.gamedev.GameLoader;

public class View extends ViewPart {
	public static final String ID = "testgame3.view";
	
	public void createPartControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.EMBEDDED);
		Frame frame = SWT_AWT.new_Frame(composite);
		frame.setBackground(Color.WHITE);
        final GameLoader game = new SWTGameLoader(frame);
        game.setup(new Tutorial7_2(), new Dimension(640, 480), false);
        new Thread(new Runnable() {
			public void run() {
		        game.start();
			}
		}).start();
	}

	public void setFocus() {
		//viewer.getControl().setFocus();
	}
}