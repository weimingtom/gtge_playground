package testgame2;
import java.awt.*;
import java.awt.image.*;

import ugame.nanami.*;

public class Tutorial7_1 extends Game {
    Sprite sprite1;
    Sprite sprite2;

    @Override
    public void initResources() {
	BufferedImage image = getImage("resources/plane1.png");
	double posx = 150;
	double posy = 100;
	sprite1 = new Sprite(image, posx, posy);
	sprite2 = new Sprite(getImage("resources/plane1.png"), 425, 100);
    }

    @Override
    public void update(long elapsedTime) {
	sprite1.update(elapsedTime);
	sprite2.update(elapsedTime);
    }

    @Override
    public void render(Graphics2D g) {
	g.setColor(Color.BLUE);
	g.fillRect(0, 0, getWidth(), getHeight());
	sprite1.render(g);
	sprite2.render(g);
    }

    public static void main(String[] args) {
	GameLoader game = new GameLoader();
	game.setup(new Tutorial7_1(), new Dimension(640, 480), false);
	game.start();
    }
}