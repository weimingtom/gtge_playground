package testgame2;

import java.awt.Dimension;
import java.awt.Frame;

import org.eclipse.swt.SWT;
import org.eclipse.swt.awt.SWT_AWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import ugame.nanami.GameLoader;

public class View extends ViewPart {
	public static final String ID = "testgame2.view";

	public static Frame FRAME;
	
	public void createPartControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.EMBEDDED | SWT.NO_BACKGROUND);
		FRAME = SWT_AWT.new_Frame(composite);
		
		Thread thread = new Thread(new Runnable() {
			public void run() {
		        GameLoader game = new GameLoader();
		        game.setup(new Tutorial7_1(), new Dimension(640,480), false);
		        game.start();				
			}
		});
		thread.start();
	}

	public void setFocus() {
		
	}
}