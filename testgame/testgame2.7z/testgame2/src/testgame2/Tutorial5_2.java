package testgame2;
import java.awt.*;
import java.awt.event.*;

import ugame.nanami.Game;
import ugame.nanami.GameLoader;

public class Tutorial5_2 extends Game {
    public void initResources() {
    }

    public void update(long elapsedTime) {
        if (keyPressed(KeyEvent.VK_ESCAPE)) {
            finish();
        }
    }
    
    public void render(Graphics2D g) {
        g.setColor(Color.BLUE);
        g.fillRect(0, 0, getWidth(), getHeight());
    }
    
    public static void main(String[] args) {
        GameLoader game = new GameLoader();
        game.setup(new Tutorial5_2(), new Dimension(640,480), true);
        game.start();
    }
}