package ugame.nanami;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class ImageBackground extends Background {
    private static final long serialVersionUID = -4083512078848542717L;

    private transient BufferedImage image;

    public ImageBackground(BufferedImage image, int w, int h) {
	super(w, h);
	this.image = image;
    }

    public ImageBackground(BufferedImage image) {
	super(image.getWidth(), image.getHeight());
	this.image = image;
    }

    public BufferedImage getImage() {
	return this.image;
    }

    public void setImage(BufferedImage image) {
	this.image = image;
	this.setSize(image.getWidth(), image.getHeight());
    }

    @Override
    public void render(Graphics2D g, int xbg, int ybg, int x, int y, int w,
	    int h) {
	g.drawImage(this.image, x, y, x + w, y + h, xbg, ybg, xbg + w, ybg + h,
		null);
    }
}
