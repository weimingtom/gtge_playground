﻿package ugame.nanami;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;

/**
 * @see http://code.google.com/p/gtge/
 */
public interface BaseGraphics {
    public Graphics2D getBackBuffer();

    public boolean flip();

    public void cleanup();

    public Dimension getSize();

    public Component getComponent();

    public String getGraphicsDescription();

    public void setWindowTitle(String title);

    public String getWindowTitle();

    public void setWindowIcon(Image icon);

    public Image getWindowIcon();
}
