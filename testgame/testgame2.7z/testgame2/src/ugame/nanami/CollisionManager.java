﻿package ugame.nanami;

import java.awt.image.BufferedImage;

public abstract class CollisionManager {
    private SpriteGroup group1, group2;

    private boolean active = true;

    public CollisionManager() {

    }

    public void setCollisionGroup(SpriteGroup group1, SpriteGroup group2) {
	this.group1 = group1;
	this.group2 = group2;
    }

    public SpriteGroup getGroup1() {
	return this.group1;
    }

    public SpriteGroup getGroup2() {
	return this.group2;
    }

    public abstract void checkCollision();

    public boolean isActive() {
	return this.active;
    }

    public void setActive(boolean b) {
	this.active = b;
    }

    private final static CollisionRect iRect = new CollisionRect();

    public static boolean isPixelCollide(double x1, double y1,
	    BufferedImage image1, double x2, double y2, BufferedImage image2) {
	double width1 = x1 + image1.getWidth() - 1, height1 = y1
		+ image1.getHeight() - 1, width2 = x2 + image2.getWidth() - 1, height2 = y2
		+ image2.getHeight() - 1;
	int xstart = (int) Math.max(x1, x2), ystart = (int) Math.max(y1, y2), xend = (int) Math
		.min(width1, width2), yend = (int) Math.min(height1, height2);
	int toty = Math.abs(yend - ystart);
	int totx = Math.abs(xend - xstart);
	for (int y = 1; y < toty - 1; y++) {
	    int ny = Math.abs(ystart - (int) y1) + y;
	    int ny1 = Math.abs(ystart - (int) y2) + y;
	    for (int x = 1; x < totx - 1; x++) {
		int nx = Math.abs(xstart - (int) x1) + x;
		int nx1 = Math.abs(xstart - (int) x2) + x;
		try {
		    if (((image1.getRGB(nx, ny) & 0xFF000000) != 0x00)
			    && ((image2.getRGB(nx1, ny1) & 0xFF000000) != 0x00)) {
			return true;
		    }
		} catch (Exception e) {

		}
	    }
	}
	return false;
    }

    public static CollisionRect getIntersectionRect(double x1, double y1,
	    int width1, int height1, double x2, double y2, int width2,
	    int height2) {
	double x12 = x1 + width1, y12 = y1 + height1, x22 = x2 + width2, y22 = y2
		+ height2;
	if (x1 < x2) {
	    x1 = x2;
	}
	if (y1 < y2) {
	    y1 = y2;
	}
	if (x12 > x22) {
	    x12 = x22;
	}
	if (y12 > y22) {
	    y12 = y22;
	}
	x12 -= x1;
	y12 -= y1;
	CollisionManager.iRect.setBounds(x1, y1, (int) x12, (int) y12);
	return CollisionManager.iRect;
    }
}
