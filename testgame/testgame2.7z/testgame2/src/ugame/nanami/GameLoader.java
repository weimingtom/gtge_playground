﻿package ugame.nanami;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import testgame2.View;

public class GameLoader extends AppletMode implements WindowListener, Runnable {
    private static final long serialVersionUID = 7164725885243400217L;
    public static final String JAVA_VERSION;
    static {
	String ver = "1.4.1";
	try {
	    ver = System.getProperty("java.version");
	} catch (Exception e) {
	}
	JAVA_VERSION = ver;
    }

    public String MINIMUM_VERSION = "1.4";
    private boolean VALID_JAVA_VERSION = true;
    private String[] INFO_MSG = new String[] { "Loading Game, please wait a moment" };
    protected BaseGraphics gfx;
    protected Game game;

    public GameLoader() {

    }

    public void start() {
	if (!this.VALID_JAVA_VERSION) {
	    return;
	}
	if (this.gfx != null) {
	    if (this.game != null) {
		this.game.start();
	    }
	    return;
	}
	try {
	    String param = this.getParameter("MINIMUM_VERSION");
	    if (param != null) {
		this.MINIMUM_VERSION = param;
	    }
	} catch (Exception e) {
	    JOptionPane.showMessageDialog(null,
		    "ERROR: GameLoader.setup(Game, Dimension, Fullscreen); need to be called\n"
			    + "before calling GameLoader.start();",
		    "Game Initialization", JOptionPane.ERROR_MESSAGE);
	    System.exit(0);
	}
	if (!this.validJavaVersion()) {
	    this.INFO_MSG = new String[] {
		    "Sorry, this game requires Java " + this.MINIMUM_VERSION
			    + "++",
		    "Your machine only has Java " + GameLoader.JAVA_VERSION
			    + " installed", "",
		    "Install the latest Java Runtime Edition (JRE)",
		    "from http://www.java.com" };

	    return;
	}
	try {
	    if (this.game == null) {
		this.game = this.createAppletGame();
		if (this.game == null) {
		    JOptionPane
			    .showMessageDialog(
				    null,
				    "FATAL ERROR: Game main-class is not specified!\n"
					    + "Please subclass GameLoader class and override\n"
					    + "createAppletGame() method to return your game main class.\n\n"
					    + "For example :\n"
					    + "public class YourGameApplet extends GameLoader {\n"
					    + "   protected Game createAppletGame() {\n"
					    + "      return new YourGame();\n"
					    + "   }\n" + "}",
				    "Game Initialization",
				    JOptionPane.ERROR_MESSAGE);

		    this.VALID_JAVA_VERSION = false;
		    return;
		}
		this.gfx = this;
		this.game.bsGraphics = this.gfx;
	    }
	    super.start();
	    new Thread(this).start();
	} catch (Throwable e) {
	    this.INFO_MSG = new String[] { "UNRECOVERABLE ERROR",
		    "PLEASE CONTACT THE GAME AUTHOR" };
	    this.removeAll();
	    this.setIgnoreRepaint(false);
	    new ErrorNotificationDialog(e, this, this.getClass().getName(),
		    null);
	}
    }

    public void stop() {
	if (this.game != null) {
	    this.game.stop();
	}
    }

    public final void run() {
	if (this.game != null) {
	    this.game.start();
	}
    }

    protected Game createAppletGame() {
	try {
	    String className = this.getParameter("GAME");
	    if (className != null) {
		if (className.endsWith(".class")) {
		    className = className.substring(0, className.length() - 6);
		}
		Class mainClass = Class.forName(className);
		return (Game) mainClass.newInstance();
	    }
	} catch (Throwable e) {

	}
	return null;
    }

    public void setup(Game game, Dimension d, boolean fullscreen,
	    boolean bufferstrategy) {
	try {
	    if (!this.validJavaVersion()) {
		JOptionPane
			.showMessageDialog(
				null,
				"Sorry, this game requires Java "
					+ this.MINIMUM_VERSION
					+ "++ installed\n"
					+ "Your machine only has Java "
					+ GameLoader.JAVA_VERSION
					+ " installed\n\n"
					+ "Please install the latest Java Runtime Edition (JRE)\n"
					+ "from http://www.java.com",
				"Game Initialization",
				JOptionPane.ERROR_MESSAGE);
		System.exit(-1);
	    }
		SWTMode mode = new SWTMode(d, bufferstrategy, View.FRAME);
		mode.getFrame().removeWindowListener(
			WindowExitListener.getInstance());
		mode.getFrame().addWindowListener(this);	    
		this.gfx = mode;
	    this.game = game;
	    this.game.bsGraphics = this.gfx;
	} catch (Throwable e) {
	    e.printStackTrace();
	    JOptionPane
		    .showMessageDialog(
			    null,
			    "Fatal Error: Failed to initialize game environment!\n"
				    + "Caused by:\n"
				    + "       "
				    + e
				    + "\n"
				    + "Please send above exception to the Game Author.\n",
			    "Game Initialization", JOptionPane.ERROR_MESSAGE);
	    System.exit(-1);
	}
    }

    public void setup(Game game, Dimension d, boolean fullscreen) {
	this.setup(game, d, fullscreen, true);
    }

    public Game getGame() {
	return this.game;
    }

    public void paint(Graphics g) {
	int width = this.getSize().width, height = this.getSize().height;
	g.setColor(new Color(255, 0, 0));
	g.fillRect(0, 0, width, height);
	g.setFont(new Font("Monospaced", Font.PLAIN, 16));
	FontMetrics fm = g.getFontMetrics();
	int y = (height / 2)
		- ((fm.getHeight() + 10) * (this.INFO_MSG.length / 2));
	g.setColor(new Color(0, 0, 0));
	try {
	    ((Graphics2D) g).setRenderingHint(
		    RenderingHints.KEY_TEXT_ANTIALIASING,
		    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
	} catch (Exception e) {

	}
	for (int i = 0; i < this.INFO_MSG.length; i++) {
	    g.drawString(this.INFO_MSG[i], (width / 2)
		    - (fm.stringWidth(this.INFO_MSG[i]) / 2), y);
	    y += fm.getHeight() + 10;
	}
    }

    protected boolean validJavaVersion() {
	this.VALID_JAVA_VERSION = this.isValidVersion();
	return this.VALID_JAVA_VERSION;
    }

    private boolean isValidVersion() {
	try {
	    StringTokenizer versionToken = new StringTokenizer(
		    GameLoader.JAVA_VERSION, "."), minimumToken = new StringTokenizer(
		    this.MINIMUM_VERSION, ".");
	    int total = (versionToken.countTokens() > minimumToken
		    .countTokens()) ? versionToken.countTokens() : minimumToken
		    .countTokens();
	    String version = "";
	    String minimum = "";
	    String parsed = "";
	    for (int i = 0; i < total; i++) {
		char inc;
		try {
		    inc = versionToken.nextToken().charAt(0);
		} catch (Exception e) {
		    inc = '0';
		}
		version += inc;
		try {
		    inc = minimumToken.nextToken().charAt(0);
		    if (parsed.length() > 0) {
			parsed += ".";
		    }
		    parsed += inc;
		} catch (Exception e) {
		    inc = '0';
		}
		minimum += inc;
	    }
	    int ver = Integer.parseInt(version), min = Integer
		    .parseInt(minimum);
	    this.MINIMUM_VERSION = parsed;
	    return (ver >= min);
	} catch (Exception e) {
	    System.err.println("WARNING: MINIMUM_VERSION ["
		    + this.MINIMUM_VERSION + "] and/or " + "JAVA_VERSION ["
		    + GameLoader.JAVA_VERSION + "] value is not valid!");
	    return true;
	}
    }

    @Override
    public String getGraphicsDescription() {
	try {
	    return (this.gfx != null) ? this.gfx.getGraphicsDescription()
		    : super.getGraphicsDescription();
	} catch (Exception e) {
	    return (this.gfx != null) ? this.gfx.getClass().toString() : this
		    .getClass().toString();
	}
    }

    @Override
    public void windowClosing(WindowEvent e) {
	if (this.game != null) {
	    this.game.finish();
	}
    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }
}
