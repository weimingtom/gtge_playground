﻿package ugame.nanami;

public class BaseAudio implements Runnable {
    public static final int SINGLE = 0;
    public static final int MULTIPLE = 1;
    public static final int SINGLE_REPLAY = 2;

    private int audioPolicy = BaseAudio.MULTIPLE;
    private int maxSimultaneous;

    private BaseAudioRenderer baseRenderer;
    private BaseAudioRenderer[] renderer;
    private String[] rendererFile;
    private String lastAudioFile;
    private BaseIO base;
    private boolean exclusive;
    private boolean loop;
    private float volume;
    private boolean active;
    private int buffer;

    public BaseAudio(BaseIO base, BaseAudioRenderer baseRenderer) {
	this.base = base;
	this.baseRenderer = baseRenderer;
	this.active = baseRenderer.isAvailable();
	this.volume = 1.0f;
	this.buffer = 10;
	this.maxSimultaneous = 6;
	this.renderer = new BaseAudioRenderer[0];
	this.rendererFile = new String[0];
	Thread thread = new Thread(this);
	thread.setDaemon(true);
	thread.start();
    }

    public void run() {
	while (true) {
	    try {
		Thread.sleep(100L);
	    } catch (InterruptedException e) {

	    }
	    for (int i = 0; i < this.renderer.length; i++) {
		if (this.renderer[i].isLoop()
			&& this.renderer[i].getStatus() == BaseAudioRenderer.END_OF_SOUND) {
		    this.renderer[i].play();
		}
	    }
	}
    }

    public int play(String audiofile) {
	return this.play(audiofile, this.audioPolicy);
    }

    public int play(String audiofile, int policy) {
	this.lastAudioFile = audiofile;
	if (!this.active) {
	    return -1;
	}
	int emptyslot = (this.renderer.length <= this.buffer) ? -1 : -2;
	int playedSound = 0;
	for (int i = 0; i < this.renderer.length; i++) {
	    if (this.rendererFile[i].equals(audiofile)) {
		if (this.renderer[i].getStatus() == BaseAudioRenderer.PLAYING) {
		    playedSound++;
		}
		if (policy == BaseAudio.MULTIPLE && !this.exclusive) {
		    if (this.renderer[i].getStatus() != BaseAudioRenderer.PLAYING) {
			this.renderer[i].setVolume(this.volume);
			this.renderer[i].play();
			return i;
		    }
		} else if (policy == BaseAudio.SINGLE_REPLAY) {
		    if (this.exclusive) {
			this.stopAll();
		    } else {
			this.renderer[i].stop();
		    }
		    this.renderer[i].setVolume(this.volume);
		    this.renderer[i].play();
		    return i;
		} else {
		    if (this.exclusive) {
			this.stopAll(this.renderer[i]);
		    }
		    if (this.renderer[i].getStatus() != BaseAudioRenderer.PLAYING) {
			this.renderer[i].setVolume(this.volume);
			this.renderer[i].play();
		    }
		    return i;
		}
	    }
	    if (emptyslot == -2
		    && this.renderer[i].getStatus() != BaseAudioRenderer.PLAYING) {
		emptyslot = i;
	    }
	}
	if (playedSound >= this.maxSimultaneous) {
	    return -1;
	}
	if (emptyslot < 0) {
	    this.renderer = (BaseAudioRenderer[]) NanamiUtil.expand(
		    this.renderer, 1);
	    this.rendererFile = (String[]) NanamiUtil.expand(this.rendererFile,
		    1);
	    emptyslot = this.renderer.length - 1;
	}
	if (this.renderer[emptyslot] == null) {
	    this.renderer[emptyslot] = this.createRenderer();
	    this.renderer[emptyslot].setLoop(this.loop);
	}
	if (this.exclusive) {
	    this.stopAll();
	} else {
	    this.stop(emptyslot);
	}
	this.renderer[emptyslot].setVolume(this.volume);
	this.renderer[emptyslot].play(this.base.getURL(audiofile));
	this.rendererFile[emptyslot] = audiofile;
	return emptyslot;
    }

    public void stop(int slot) {
	if (this.renderer[slot].getStatus() == BaseAudioRenderer.PLAYING) {
	    this.renderer[slot].stop();
	}
    }

    public void stop(String audiofile) {
	BaseAudioRenderer audio = this.getAudioRenderer(audiofile);
	if (audio != null) {
	    audio.stop();
	}
    }

    public void stopAll() {
	int count = this.renderer.length;
	for (int i = 0; i < count; i++) {
	    this.stop(i);
	}
    }

    public void stopAll(BaseAudioRenderer except) {
	int count = this.renderer.length;
	for (int i = 0; i < count; i++) {
	    if (this.renderer[i] != except) {
		this.stop(i);
	    }
	}
    }

    public BaseAudioRenderer getAudioRenderer(int slot) {
	return this.renderer[slot];
    }

    public BaseAudioRenderer getAudioRenderer(String audiofile) {
	int count = this.renderer.length;
	for (int i = 0; i < count; i++) {
	    // find renderer with specified audio file
	    if (this.rendererFile[i].equals(audiofile)) {
		return this.renderer[i];
	    }
	}
	return null;
    }

    public String getLastAudioFile() {
	return this.lastAudioFile;
    }

    public BaseAudioRenderer[] getRenderers() {
	return this.renderer;
    }

    public int getCountRenderers() {
	return this.renderer.length;
    }

    public float getVolume() {
	return this.volume;
    }

    public void setVolume(float volume) {
	if (volume < 0.0f) {
	    volume = 0.0f;
	}
	if (volume > 1.0f) {
	    volume = 1.0f;
	}
	if (this.baseRenderer.isVolumeSupported() == false
		|| this.volume == volume) {
	    return;
	}
	this.volume = volume;
	int count = this.renderer.length;
	for (int i = 0; i < count; i++) {
	    this.renderer[i].setVolume(volume);
	}
    }

    public boolean isVolumeSupported() {
	return this.baseRenderer.isVolumeSupported();
    }

    public int getAudioPolicy() {
	return this.audioPolicy;
    }

    public void setAudioPolicy(int i) {
	this.audioPolicy = i;
    }

    public int getMaxSimultaneous() {
	return this.maxSimultaneous;
    }

    public void setMaxSimultaneous(int i) {
	this.maxSimultaneous = i;
    }

    public boolean isExclusive() {
	return this.exclusive;
    }

    public void setExclusive(boolean exclusive) {
	this.exclusive = exclusive;

	if (exclusive) {
	    this.stopAll();
	}
    }

    public int getBuffer() {
	return this.buffer;
    }

    public void setBuffer(int i) {
	this.buffer = i;
    }

    public boolean isLoop() {
	return this.loop;
    }

    public void setLoop(boolean loop) {
	if (this.loop == loop) {
	    return;
	}
	this.loop = loop;
	int count = this.renderer.length;
	for (int i = 0; i < count; i++) {
	    this.renderer[i].setLoop(loop);
	}
    }

    public BaseIO getBaseIO() {
	return this.base;
    }

    public void setBaseIO(BaseIO base) {
	this.base = base;
    }

    public boolean isActive() {
	return this.active;
    }

    public void setActive(boolean b) {
	this.active = (this.isAvailable()) ? b : false;
	if (!this.active) {
	    this.stopAll();
	}
    }

    public boolean isAvailable() {
	return this.baseRenderer.isAvailable();
    }

    public BaseAudioRenderer getBaseRenderer() {
	return this.baseRenderer;
    }

    public void setBaseRenderer(BaseAudioRenderer renderer) {
	this.baseRenderer = renderer;

	if (this.active) {
	    this.active = this.baseRenderer.isAvailable();
	}
    }

    protected BaseAudioRenderer createRenderer() {
	try {
	    return (BaseAudioRenderer) Class.forName(
		    this.baseRenderer.getClass().getName()).newInstance();
	} catch (Exception e) {
	    throw new RuntimeException(
		    "Unable to create new instance of audio renderer on "
			    + this
			    + " audio manager caused by: "
			    + e.getMessage()
			    + "\n"
			    + "Make sure the base renderer has one empty constructor!");
	}
    }

}
