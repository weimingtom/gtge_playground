﻿package ugame.nanami;

public interface BaseTimer {
    public void startTimer();

    public void stopTimer();

    public long sleep();

    public long getTime();

    public void refresh();

    public boolean isRunning();

    public int getCurrentFPS();

    public int getFPS();

    public void setFPS(int fps);
}
