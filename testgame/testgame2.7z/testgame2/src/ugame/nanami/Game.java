﻿package ugame.nanami;

import java.applet.Applet;
import java.awt.AlphaComposite;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Transparency;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;

public abstract class Game {
    public static final String GTGE_VERSION = "0.2.4";
    private static final int DEFAULT_FPS = 100;
    public BaseGraphics bsGraphics;
    public BaseIO bsIO;
    public BaseLoader bsLoader;
    public BaseInput bsInput;
    public BaseTimer bsTimer;
    public BaseAudio bsMusic;
    public BaseAudio bsSound;
    public GameFontManager fontManager;

    private boolean running;
    private boolean finish;
    protected boolean distribute;

    GameFont fpsFont;
    private boolean development;
    private boolean initialized;
    boolean inFocus = true;
    private boolean inFocusBlink;
    private boolean pauseOnLostFocus = false;

    public Game() {

    }

    public void stop() {
	this.running = false;
    }

    public void finish() {
	this.finish = true;
	this.stop();
    }

    public boolean isFinish() {
	return this.finish;
    }

    public boolean isRunning() {
	return this.running;
    }

    public final void start() {
	if (this.running || this.finish) {
	    return;
	}
	this.running = true;
	if (this.initialized == false) {
	    this.development = !this.distribute;
	}
	if (this.development == false) {
	    try {
		if (this.initialized == false) {
		    this.initialized = true;
		    this.initialize();
		}
		this.startGameLoop();
	    } catch (Throwable e) {
		this.notifyError(e);
	    }
	} else {
	    if (this.initialized == false) {
		this.initialized = true;
		this.initialize();
	    }
	    this.startGameLoop();
	}
    }

    private void initialize() {
	if (this.bsGraphics instanceof Applet) {
	    this.setPauseOnLostFocus(true);
	}
	this.initEngine();
	try {
	    this.bsGraphics.getComponent().addFocusListener(
		    new FocusListener() {
			public void focusGained(FocusEvent e) {
			    Game.this.inFocus = true;
			}

			public void focusLost(FocusEvent e) {
			    if (Game.this.pauseOnLostFocus) {
				Game.this.inFocus = false;
			    }
			}
		    });
	} catch (Exception e) {

	}
	if (this.development == false) {
	    this.showLogo();
	}
	try {
	    URL fontURL = Game.class.getResource("Game.png");
	    BufferedImage fpsImage = NanamiUtil.getImage(fontURL);
	    this.fpsFont = this.fontManager.getFont(fpsImage);
	    this.fontManager.removeFont(fpsImage);
	    this.fontManager.putFont("FPS Font", this.fpsFont);
	    if (this.development == false) {
		this.fpsFont = null;
	    }
	} catch (Exception e) {
	    this.bailOut();
	}
	System.gc();
	System.runFinalization();
	this.initResources();
    }

    void startGameLoop() {
	System.gc();
	System.runFinalization();
	this.bsTimer.startTimer();
	this.bsTimer.refresh();
	long elapsedTime = 0;
	out: while (true) {
	    if (this.inFocus) {
		this.update(elapsedTime);
		this.bsInput.update(elapsedTime);
	    } else {
		try {
		    Thread.sleep(300);
		} catch (InterruptedException e) {

		}
	    }
	    do {
		if (!this.running) {
		    break out;
		}
		Graphics2D g = this.bsGraphics.getBackBuffer();
		this.render(g);
		if (!this.inFocus) {
		    this.renderLostFocus(g);
		}
	    } while (this.bsGraphics.flip() == false);
	    elapsedTime = this.bsTimer.sleep();
	    if (elapsedTime > 100) {
		elapsedTime = 100;
	    }
	}
	this.bsTimer.stopTimer();
	this.bsSound.stopAll();
	this.bsMusic.stopAll();
	if (this.finish) {
	    this.bsGraphics.cleanup();
	    this.notifyExit();
	}
    }

    protected void renderLostFocus(Graphics2D g) {
	String st1 = "GAME IS NOT IN FOCUSED", st2 = "CLICK HERE TO GET THE FOCUS BACK";

	g.setFont(new Font("Dialog", Font.BOLD, 15));
	FontMetrics fm = g.getFontMetrics();
	int posy = (this.getHeight() / 2) - ((fm.getHeight() + 10) * (2 / 2));
	int x = (this.getWidth() / 2) - (fm.stringWidth(st2) / 2) - 20, y = posy - 25, width = fm
		.stringWidth(st2) + 40, height = fm.getHeight()
		+ fm.getHeight() + 30;
	g.setColor(Color.BLACK);
	g.fillRect(x, y, width - 1, height - 1);
	g.setColor(Color.RED);
	g.drawRect(x, y, width - 1, height - 1);
	this.inFocusBlink = !this.inFocusBlink;
	if (!this.inFocusBlink) {
	    try {
		((Graphics2D) g).setRenderingHint(
			RenderingHints.KEY_TEXT_ANTIALIASING,
			RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
	    } catch (Exception e) {

	    }
	    g.setColor(Color.RED);
	    g.drawString(st1,
		    (this.getWidth() / 2) - (fm.stringWidth(st1) / 2), posy);
	    posy += fm.getHeight() + 10;
	    g.drawString(st2,
		    (this.getWidth() / 2) - (fm.stringWidth(st2) / 2), posy);
	}
    }

    public void setPauseOnLostFocus(boolean b) {
	this.pauseOnLostFocus = b;
	if (this.pauseOnLostFocus == false) {
	    this.inFocus = true;
	}
    }

    public boolean isPauseOnLostFocus() {
	return this.pauseOnLostFocus;
    }

    protected void initEngine() {
	if (this.bsTimer == null) {
	    this.bsTimer = new NanamiSystemTimer();
	}
	if (this.bsIO == null) {
	    this.bsIO = new BaseIO(this.getClass());
	}
	if (this.bsLoader == null) {
	    this.bsLoader = new BaseLoader(this.bsIO, Color.MAGENTA);
	}
	if (this.bsInput == null) {
	    this.bsInput = new AWTInput(this.bsGraphics.getComponent());
	}
	if (this.bsMusic == null) {
	    this.bsMusic = new BaseAudio(this.bsIO, new MidiRenderer());
	    this.bsMusic.setExclusive(true);
	    this.bsMusic.setLoop(true);
	}
	if (this.bsSound == null) {
	    this.bsSound = new BaseAudio(this.bsIO, new WaveRenderer());
	}
	this.bsTimer.setFPS(Game.DEFAULT_FPS);
	Background.screen = this.bsGraphics.getSize();
	if (this.fontManager == null) {
	    this.fontManager = new GameFontManager();
	}
    }

    public abstract void initResources();

    public abstract void update(long elapsedTime);

    public abstract void render(Graphics2D g);

    protected void notifyExit() {
	if ((this.bsGraphics instanceof Applet) == false) {
	    try {
		System.exit(0);
	    } catch (Exception e) {

	    }
	} else {
	    final Applet applet = (Applet) this.bsGraphics;
	    BufferedImage src = NanamiUtil.createImage(this.getWidth(), this
		    .getHeight());
	    Graphics2D g = src.createGraphics();
	    try {
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		g.setComposite(AlphaComposite.getInstance(
			AlphaComposite.SRC_OVER, 0.8f));
		Shape shape = new java.awt.geom.Ellipse2D.Float(
			this.getWidth() / 10, this.getHeight() / 10, this
				.getWidth()
				- (this.getWidth() / 10 * 2), this.getHeight()
				- (this.getHeight() / 10 * 2));
		g.setClip(shape);
		if (this instanceof GameEngine) {
		    ((GameEngine) this).getCurrentGame().render(g);
		}
		this.render(g);
		g.dispose();
	    } catch (Exception e) {
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		g.dispose();
	    }
	    BufferedImage converted = null;
	    try {
		BufferedImage image = new BufferedImage(src.getWidth(), src
			.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
		Graphics gfx = image.getGraphics();
		gfx.drawImage(src, 0, 0, null);
		gfx.dispose();
		converted = image;
	    } catch (Throwable e) {

	    }
	    final BufferedImage image = (converted != null) ? converted : src;
	    applet.removeAll();
	    applet.setIgnoreRepaint(false);
	    Canvas canvas = new Canvas() {
		private static final long serialVersionUID = 8493852179266447783L;

		@Override
		public void paint(Graphics g1) {
		    Graphics2D g = (Graphics2D) g1;
		    g.drawImage(image, 0, 0, null);
		    g.setColor(Color.YELLOW);
		    g.setFont(new Font("Verdana", Font.BOLD, 12));
		    g.drawString("Game has been ended", 10, 25);
		    g.drawString("Thank you for playing!", 10, 45);
		    g.drawString("Visit http://www.goldenstudios.or.id/", 10,
			    75);
		    g.drawString("For free game engine!", 10, 95);
		    g.drawString("This game is developed with GTGE v"
			    + Game.GTGE_VERSION, 10, 115);
		}
	    };
	    canvas.setSize(applet.getSize());
	    canvas.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent e) {
		    try {
			applet.getAppletContext().showDocument(
				new URL("http://goldenstudios.or.id/"));
		    } catch (Exception excp) {

		    }
		}
	    });
	    applet.add(canvas);
	    applet.repaint();
	    canvas.repaint();
	}
    }

    protected void notifyError(Throwable error) {
	new ErrorNotificationDialog(error, this.bsGraphics, this.getClass()
		.getName(), null);
    }

    public final boolean isDistribute() {
	return (this.development == false);
    }

    public final void showLogo() {
	this.hideCursor();
	NanamiSystemTimer dummyTimer = new NanamiSystemTimer();
	dummyTimer.setFPS(20);
	this.bsInput.refresh();
	BufferedImage logo = null;
	try {
	    URL logoURL = Game.class.getResource("Game.jpg");
	    BufferedImage orig = NanamiUtil.getImage(logoURL);
	    logo = NanamiUtil.resize(orig, this.getWidth(), this.getHeight());
	    orig.flush();
	    orig = null;
	} catch (Exception e) {
	    this.bailOut();
	}
	try {
	    this.clearScreen(Color.BLACK);
	    Thread.sleep(1000L);
	} catch (InterruptedException e) {

	}
	if (!this.inFocus) {
	    while (!this.inFocus) {
		Graphics2D g = this.bsGraphics.getBackBuffer();
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		this.renderLostFocus(g);
		this.bsGraphics.flip();
		try {
		    Thread.sleep(200);
		} catch (InterruptedException e) {

		}
	    }
	    this.bsInput.refresh();
	    try {
		Thread.sleep(1000);
	    } catch (InterruptedException e) {
	    }
	}
	float alpha = 0.0f;
	dummyTimer.startTimer();
	boolean firstTime = true;
	while (alpha < 1.0f) {
	    do {
		if (!this.running) {
		    return;
		}
		Graphics2D g = this.bsGraphics.getBackBuffer();
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		Composite old = g.getComposite();
		g.setComposite(AlphaComposite.getInstance(
			AlphaComposite.SRC_OVER, alpha));
		g.drawImage(logo, 0, 0, null);
		g.setComposite(old);
	    } while (this.bsGraphics.flip() == false);
	    if (firstTime) {
		firstTime = false;
		dummyTimer.refresh();
	    }
	    long elapsedTime = dummyTimer.sleep();
	    double increment = 0.00065 * elapsedTime;
	    if (increment > 0.22) {
		increment = 0.22 + (increment / 6);
	    }
	    alpha += increment;
	    if (this.isSkip(elapsedTime)) {
		this.clearScreen(Color.BLACK);
		logo.flush();
		logo = null;
		return;
	    }
	}
	do {
	    if (!this.running) {
		return;
	    }
	    Graphics2D g = this.bsGraphics.getBackBuffer();
	    g.drawImage(logo, 0, 0, null);
	} while (this.bsGraphics.flip() == false);
	int i = 0;
	while (i++ < 50) {
	    if (!this.running) {
		return;
	    }
	    try {
		Thread.sleep(50L);
	    } catch (InterruptedException e) {

	    }
	    if (this.isSkip(50)) {
		this.clearScreen(Color.BLACK);
		logo.flush();
		logo = null;
		return;
	    }
	}
	alpha = 1.0f;
	dummyTimer.refresh();
	while (alpha > 0.0f) {
	    do {
		if (!this.running) {
		    return;
		}
		Graphics2D g = this.bsGraphics.getBackBuffer();
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		Composite old = g.getComposite();
		g.setComposite(AlphaComposite.getInstance(
			AlphaComposite.SRC_OVER, alpha));
		g.drawImage(logo, 0, 0, null);
		g.setComposite(old);
	    } while (this.bsGraphics.flip() == false);
	    long elapsedTime = dummyTimer.sleep();
	    double decrement = 0.00055 * elapsedTime;
	    if (decrement > 0.15) {
		decrement = 0.15 + ((decrement - 0.04) / 2);
	    }
	    alpha -= decrement;
	    if (this.isSkip(elapsedTime)) {
		this.clearScreen(Color.BLACK);
		logo.flush();
		logo = null;
		return;
	    }
	}
	logo.flush();
	logo = null;
	dummyTimer.stopTimer();
	dummyTimer = null;
	try {
	    this.clearScreen(Color.BLACK);
	    Thread.sleep(100L);
	} catch (InterruptedException e) {

	}
    }

    private boolean isSkip(long elapsedTime) {
	boolean skip = (this.bsInput.getKeyPressed() != BaseInput.NO_KEY || this.bsInput
		.getMousePressed() != BaseInput.NO_BUTTON);
	this.bsInput.update(elapsedTime);
	return skip;
    }

    private void clearScreen(Color col) {
	Graphics2D g = this.bsGraphics.getBackBuffer();
	g.setColor(col);
	g.fillRect(0, 0, this.getWidth(), this.getHeight());
	this.bsGraphics.flip();
	g = this.bsGraphics.getBackBuffer();
	g.setColor(col);
	g.fillRect(0, 0, this.getWidth(), this.getHeight());
	this.bsGraphics.flip();
    }

    private void bailOut() {
	try {
	    URL fontURL = Game.class.getResource("Game.fnt");
	    BufferedImage fpsImage = NanamiUtil.getImage(fontURL);
	    this.fontManager = new GameFontManager();
	    GameFont font = this.fontManager.getFont(fpsImage);
	    Graphics2D g = this.bsGraphics.getBackBuffer();
	    g.setColor(Color.RED.darker());
	    g.fillRect(0, 0, this.getWidth(), this.getHeight());
	    font.drawString(g, "THIS GAME IS USING", 10, 10);
	    font.drawString(g, "GTGE CRACKED VERSION!!", 10, 30);
	    font.drawString(g, "PLEASE REPORT THIS GAME TO", 10, 50);
	    font.drawString(g, "WWW.GOLDENSTUDIOS.OR.ID", 10, 70);
	    font.drawString(g, "THANK YOU....", 10, 105);
	    this.bsGraphics.flip();
	    this.bsInput = new AWTInput(this.bsGraphics.getComponent());
	    try {
		int i = 0;
		do {
		    Thread.sleep(50L);
		} while (++i < 160 && this.isSkip(50) == false);
	    } catch (InterruptedException e) {

	    }
	    this.finish();
	} catch (Throwable e) {

	}
	System.out.println("THIS GAME IS USING GTGE CRACKED VERSION!!");
	System.out
		.println("PLEASE REPORT THIS GAME TO HTTP://WWW.GOLDENSTUDIOS.OR.ID/");
	System.out.println("THANK YOU....");
	System.exit(-1);
    }

    public int getRandom(int low, int hi) {
	return NanamiUtil.getRandom(low, hi);
    }

    public int getWidth() {
	return this.bsGraphics.getSize().width;
    }

    public int getHeight() {
	return this.bsGraphics.getSize().height;
    }

    public BufferedImage takeScreenShot() {
	BufferedImage screen = NanamiUtil.createImage(this.getWidth(), this
		.getHeight(), Transparency.OPAQUE);
	Graphics2D g = screen.createGraphics();
	this.render(g);
	g.dispose();
	return screen;
    }

    public void takeScreenShot(File f) {
	NanamiUtil.saveImage(this.takeScreenShot(), f);
    }

    public int playMusic(String audiofile) {
	return this.bsMusic.play(audiofile);
    }

    public int playSound(String audiofile) {
	return this.bsSound.play(audiofile);
    }

    public void setFPS(int fps) {
	this.bsTimer.setFPS(fps);
    }

    public int getCurrentFPS() {
	return this.bsTimer.getCurrentFPS();
    }

    public int getFPS() {
	return this.bsTimer.getFPS();
    }

    public void drawFPS(Graphics2D g, int x, int y) {
	this.fontManager.getFont("FPS Font").drawString(g,
		"FPS = " + this.getCurrentFPS() + "/" + this.getFPS(), x, y);
    }

    public int getMouseX() {
	return this.bsInput.getMouseX();
    }

    public int getMouseY() {
	return this.bsInput.getMouseY();
    }

    public boolean checkPosMouse(int x1, int y1, int x2, int y2) {
	return (this.getMouseX() >= x1 && this.getMouseY() >= y1
		&& this.getMouseX() <= x2 && this.getMouseY() <= y2);
    }

    public boolean checkPosMouse(Sprite sprite, boolean pixelCheck) {
	Background bg = sprite.getBackground();
	if (this.getMouseX() < bg.getClip().x
		|| this.getMouseY() < bg.getClip().y
		|| this.getMouseX() > bg.getClip().x + bg.getClip().width
		|| this.getMouseY() > bg.getClip().y + bg.getClip().height) {
	    return false;
	}

	double mosx = this.getMouseX() + bg.getX() - bg.getClip().x;
	double mosy = this.getMouseY() + bg.getY() - bg.getClip().y;

	if (pixelCheck) {
	    try {
		return ((sprite.getImage().getRGB((int) (mosx - sprite.getX()),
			(int) (mosy - sprite.getY())) & 0xFF000000) != 0x00);
	    } catch (Exception e) {
		return false;
	    }

	} else {
	    return (mosx >= sprite.getX() && mosy >= sprite.getY()
		    && mosx <= sprite.getX() + sprite.getWidth() && mosy <= sprite
		    .getY()
		    + sprite.getHeight());
	}
    }

    public Sprite checkPosMouse(SpriteGroup group, boolean pixelCheck) {
	Sprite[] sprites = group.getSprites();
	int size = group.getSize();
	for (int i = 0; i < size; i++) {
	    if (sprites[i].isActive()
		    && this.checkPosMouse(sprites[i], pixelCheck)) {
		return sprites[i];
	    }
	}
	return null;
    }

    public Sprite checkPosMouse(PlayField field, boolean pixelCheck) {
	SpriteGroup[] groups = field.getGroups();
	int size = groups.length;
	for (int i = 0; i < size; i++) {
	    if (groups[i].isActive()) {
		Sprite s = this.checkPosMouse(groups[i], pixelCheck);
		if (s != null) {
		    return s;
		}
	    }
	}
	return null;
    }

    public boolean click() {
	return this.bsInput.isMousePressed(MouseEvent.BUTTON1);
    }

    public boolean rightClick() {
	return this.bsInput.isMousePressed(MouseEvent.BUTTON3);
    }

    public boolean keyDown(int keyCode) {
	return this.bsInput.isKeyDown(keyCode);
    }

    public boolean keyPressed(int keyCode) {
	return this.bsInput.isKeyPressed(keyCode);
    }

    public void hideCursor() {
	this.bsInput.setMouseVisible(false);
    }

    public void showCursor() {
	this.bsInput.setMouseVisible(true);
    }

    public void setMaskColor(Color c) {
	this.bsLoader.setMaskColor(c);
    }

    public BufferedImage getImage(String imagefile, boolean useMask) {
	return this.bsLoader.getImage(imagefile, useMask);
    }

    public BufferedImage getImage(String imagefile) {
	return this.bsLoader.getImage(imagefile);
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    boolean useMask) {
	return this.bsLoader.getImages(imagefile, col, row, useMask);
    }

    public BufferedImage[] getImages(String imagefile, int col, int row) {
	return this.bsLoader.getImages(imagefile, col, row);
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    boolean useMask, String sequence, int digit) {
	String mapping = imagefile + sequence + digit;
	BufferedImage[] image = this.bsLoader.getStoredImages(mapping);
	if (image == null) {
	    BufferedImage[] src = this.getImages(imagefile, col, row, useMask);
	    int count = sequence.length() / digit;
	    image = new BufferedImage[count];
	    for (int i = 0; i < count; i++) {
		image[i] = src[Integer.parseInt(sequence.substring(i * digit,
			((i + 1) * digit)))];
	    }
	    this.bsLoader.storeImages(mapping, image);
	}
	return image;
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    String sequence, int digit) {
	return this.getImages(imagefile, col, row, true, sequence, digit);
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    boolean useMask, int start, int end) {
	String mapping = start + imagefile + end;
	BufferedImage[] image = this.bsLoader.getStoredImages(mapping);
	if (image == null) {
	    BufferedImage[] src = this.getImages(imagefile, col, row, useMask);
	    int count = end - start + 1;
	    image = new BufferedImage[count];
	    for (int i = 0; i < count; i++) {
		image[i] = src[start + i];
	    }
	    this.bsLoader.storeImages(mapping, image);
	}
	return image;
    }

    public BufferedImage[] getImages(String imagefile, int col, int row,
	    int start, int end) {
	return this.getImages(imagefile, col, row, true, start, end);
    }

}
