﻿package ugame.nanami;

/**
 * @see http://code.google.com/p/gtge/
 */
public class NanamiFPSCounter {
    private long lastCount;
    private int currentFPS;
    private int frameCount;

    public NanamiFPSCounter() {

    }

    public void refresh() {
	this.frameCount = 0;
	this.lastCount = System.currentTimeMillis();
    }

    public void calculateFPS() {
	this.frameCount++;
	if (System.currentTimeMillis() - this.lastCount > 1000) {
	    this.lastCount = System.currentTimeMillis();
	    this.currentFPS = this.frameCount;
	    this.frameCount = 0;
	}
    }

    public int getCurrentFPS() {
	return this.currentFPS;
    }
}
