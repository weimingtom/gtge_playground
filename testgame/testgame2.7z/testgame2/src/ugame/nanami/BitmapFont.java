﻿package ugame.nanami;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class BitmapFont implements GameFont {
    private BufferedImage[] imagefont;
    private int w, h;
    protected int[] charIndex = new int[256];

    public BitmapFont(BufferedImage[] imagefont, String letterSequence) {
	this.imagefont = imagefont;

	this.w = imagefont[0].getWidth();
	this.h = imagefont[0].getHeight();

	for (int i = 0; i < this.charIndex.length; i++) {
	    this.charIndex[i] = -1;
	}

	int totalLetter = letterSequence.length();
	for (int i = 0; i < totalLetter; i++) {
	    this.charIndex[(int) letterSequence.charAt(i)] = i;
	}
    }

    public BitmapFont(BufferedImage[] imagefont) {
	this(imagefont, " !\"#$%&'()*+,-./0123" + "456789:;<=>?@ABCDEFG"
		+ "HIJKLMNOPQRSTUVWXYZ[" + "\\]^_`abcdefghijklmno"
		+ "pqrstuvwxyz{|}~");
    }

    @Override
    public int drawString(Graphics2D g, String s, int x, int y) {
	int len = s.length();
	int index = 0;
	char letter;
	for (int i = 0; i < len; i++) {
	    letter = s.charAt(i);
	    index = this.charIndex[(int) letter];
	    if (index != -1) {
		try {
		    g.drawImage(this.imagefont[index], x, y, null);
		    x += this.getWidth(letter);
		} catch (Exception e) {
		    throw new RuntimeException(this
			    + "\nunable to draw letter '" + s.charAt(i) + "'["
			    + (i + 1) + "] in " + "\"" + s + "\"! charIndex = "
			    + index + "\n" + "caused by : " + e);
		}
	    } else {
		throw new RuntimeException(this + "\nunable to draw letter ["
			+ s.charAt(i) + "] (" + (i + 1) + ") in " + "[" + s
			+ "] text! ");
	    }
	}
	return x;
    }

    @Override
    public int drawString(Graphics2D g, String s, int alignment, int x, int y,
	    int width) {
	if (alignment == GameFont.LEFT) {
	    return this.drawString(g, s, x, y);
	} else if (alignment == GameFont.CENTER) {
	    return this.drawString(g, s, x + (width / 2)
		    - (this.getWidth(s) / 2), y);
	} else if (alignment == GameFont.RIGHT) {
	    return this.drawString(g, s, x + width - this.getWidth(s), y);
	} else if (alignment == GameFont.JUSTIFY) {
	    int mod = width - this.getWidth(s);
	    if (mod <= 0) {
		return this.drawString(g, s, x, y);
	    }
	    String st;
	    int len = s.length();
	    int space = 0;
	    int curpos = 0;
	    int endpos = 0;
	    while (curpos < len) {
		if (s.charAt(curpos++) == ' ') {
		    space++;
		}
	    }
	    if (space > 0) {
		mod += this.w * space;
		space = mod / space;
	    }
	    curpos = endpos = 0;
	    while (curpos < len) {
		endpos = s.indexOf(' ', curpos);
		if (endpos == -1) {
		    endpos = len;
		}
		st = s.substring(curpos, endpos);
		this.drawString(g, st, x, y);
		x += this.getWidth(st) + space;
		curpos = endpos + 1;
	    }
	    return x;
	}
	return 0;
    }

    @Override
    public int drawText(Graphics2D g, String text, int alignment, int x, int y,
	    int width, int vspace, int firstIndent) {
	boolean firstLine = true;
	int curpos, startpos, endpos;
	int len = text.length();
	int posx = firstIndent;
	curpos = startpos = endpos = 0;
	char curChr;
	while (curpos < len) {
	    curChr = text.charAt(curpos++);
	    posx += this.getWidth(curChr);
	    if (curChr - ' ' == 0) {
		endpos = curpos - 1;
	    }
	    if (posx >= width) {
		if (firstLine) {
		    this.drawString(g, text.substring(startpos, endpos),
			    alignment, (alignment == GameFont.RIGHT) ? x : x
				    + firstIndent, y, width - firstIndent);
		    firstLine = false;
		} else {
		    this.drawString(g, text.substring(startpos, endpos),
			    alignment, x, y, width);
		}
		y += this.getHeight() + vspace;
		posx = 0;
		startpos = curpos = endpos + 1;
	    }
	}
	if (firstLine) {
	    this.drawString(g, text.substring(startpos, curpos), alignment,
		    (alignment == GameFont.RIGHT) ? x : x + firstIndent, y,
		    width - firstIndent);
	} else if (posx != 0) {
	    this.drawString(g, text.substring(startpos, curpos), alignment, x,
		    y, width);
	}
	return y + this.getHeight();
    }

    public BufferedImage[] getImageFont() {
	return this.imagefont;
    }

    public void setImageFont(BufferedImage[] imagefont, String letterSequence) {
	this.imagefont = imagefont;
	this.w = imagefont[0].getWidth();
	this.h = imagefont[0].getHeight();
	for (int i = 0; i < this.charIndex.length; i++) {
	    this.charIndex[i] = -1;
	}
	int totalLetter = letterSequence.length();
	for (int i = 0; i < totalLetter; i++) {
	    this.charIndex[(int) letterSequence.charAt(i)] = i;
	}
    }

    @Override
    public int getWidth(char c) {
	return this.w;
    }

    @Override
    public int getWidth(String st) {
	return st.length() * this.w;
    }

    @Override
    public int getHeight() {
	return this.h;
    }

    @Override
    public String toString() {
	return super.toString() + " " + "[totalChar=" + this.imagefont.length
		+ ", width=" + this.w + ", height=" + this.h + "]";
    }

    @Override
    public boolean isAvailable(char c) {
	try {
	    return (this.charIndex[(int) c] != -1);
	} catch (Exception e) {
	    return false;
	}
    }

}
