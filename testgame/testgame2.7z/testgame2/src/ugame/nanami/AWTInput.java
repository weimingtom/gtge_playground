﻿package ugame.nanami;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

public class AWTInput implements BaseInput {
    private Component component;
    private InputListener listener;
    private int mouseX, mouseY;
    private int lastMouseX, lastMouseY;
    private int mouseDX, mouseDY;
    private boolean mouseExists;
    private boolean mouseVisible;
    private boolean[] mouseDown;
    private int[] mousePressed;
    private int[] mouseReleased;
    private int pressedMouse;
    private int releasedMouse;
    private boolean[] keyDown;
    int[] keyPressed;
    int[] keyReleased;
    int pressedKey;
    int releasedKey;
    private KeyTyped keyTyped;

    public AWTInput(Component comp) {
	this.component = comp;
	this.component.requestFocus();
	this.listener = this.createInputListener();
	this.component.addKeyListener(this.listener);
	this.component.addMouseListener(this.listener);
	this.component.addMouseMotionListener(this.listener);
	this.component.addFocusListener(this.listener);
	this.keyDown = new boolean[255];
	this.keyPressed = this.keyReleased = new int[20];
	this.pressedKey = this.releasedKey = 0;
	this.keyTyped = new KeyTyped(this);
	this.mouseExists = true;
	this.mouseVisible = true;
	this.mouseDown = new boolean[4];
	this.mousePressed = this.mouseReleased = new int[4];
	this.pressedMouse = this.releasedMouse = 0;
	this.mouseX = this.mouseY = this.lastMouseX = this.lastMouseY = this.mouseDX = this.mouseDY = 0;
	try {
	    GraphicsDevice device = GraphicsEnvironment
		    .getLocalGraphicsEnvironment().getDefaultScreenDevice();
	    DisplayMode mode = device.getDisplayMode();
	    this.mouseX = this.lastMouseX = (mode.getWidth() / 2) - 10;
	    this.mouseY = this.lastMouseY = (mode.getHeight() / 2) - 10;
	    (new Robot()).mouseMove(this.mouseX, this.mouseY);
	} catch (Throwable e) {

	}
	comp.setFocusTraversalKeysEnabled(false);
    }

    protected InputListener createInputListener() {
	return new InputListener();
    }

    @Override
    public void update(long elapsedTime) {
	this.keyTyped.update(elapsedTime);
	this.pressedMouse = this.releasedMouse = 0;
	this.mouseDX = this.mouseX - this.lastMouseX;
	this.mouseDY = this.mouseY - this.lastMouseY;
	this.lastMouseX = this.mouseX;
	this.lastMouseY = this.mouseY;
	this.pressedKey = this.releasedKey = 0;
    }

    @Override
    public void refresh() {
	this.keyTyped.refresh();
	for (int i = 0; i < this.mouseDown.length; i++) {
	    this.mouseDown[i] = false;
	}
	this.pressedMouse = this.releasedMouse = 0;
	this.mouseDX = this.mouseDY = 0;
	for (int i = 0; i < this.keyDown.length; i++) {
	    this.keyDown[i] = false;
	}
	this.pressedKey = this.releasedKey = 0;
    }

    @Override
    public void cleanup() {
	try {
	    this.component.removeKeyListener(this.listener);
	    this.component.removeMouseListener(this.listener);
	    this.component.removeMouseMotionListener(this.listener);
	    this.component.removeFocusListener(this.listener);
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    @Override
    public void mouseMove(int x, int y) {
	try {
	    new Robot().mouseMove(x, y);
	} catch (Exception e) {
	    System.err.println("WARNING: Can't move the mouse pointer to " + x
		    + ", " + y);
	}
    }

    @Override
    public boolean isMouseExists() {
	return this.mouseExists;
    }

    @Override
    public int getMouseX() {
	return this.mouseX;
    }

    @Override
    public int getMouseY() {
	return this.mouseY;
    }

    @Override
    public int getMouseDX() {
	return this.mouseDX;
    }

    @Override
    public int getMouseDY() {
	return this.mouseDY;
    }

    @Override
    public void setMouseVisible(boolean visible) {
	if (this.mouseVisible == visible) {
	    return;
	}
	this.mouseVisible = visible;
	if (!visible) {
	    Toolkit t = Toolkit.getDefaultToolkit();
	    Dimension d = t.getBestCursorSize(1, 1);
	    if (d.width == 0 || d.height == 0) {
		d.width = d.height = 1;
	    }
	    BufferedImage nullImg = new BufferedImage(d.width, d.height,
		    BufferedImage.TYPE_INT_ARGB);
	    Cursor c = t.createCustomCursor(nullImg, new Point(0, 0), "null");
	    this.component.setCursor(c);
	} else {
	    this.component.setCursor(Cursor.getDefaultCursor());
	}
    }

    @Override
    public boolean isMouseVisible() {
	return this.mouseVisible;
    }

    @Override
    public int getMousePressed() {
	return (this.pressedMouse > 0) ? this.mousePressed[0]
		: BaseInput.NO_BUTTON;
    }

    @Override
    public boolean isMousePressed(int button) {
	for (int i = 0; i < this.pressedMouse; i++) {
	    if (this.mousePressed[i] == button) {
		return true;
	    }
	}
	return false;
    }

    @Override
    public int getMouseReleased() {
	return (this.releasedMouse > 0) ? this.mouseReleased[0]
		: BaseInput.NO_BUTTON;
    }

    @Override
    public boolean isMouseReleased(int button) {
	for (int i = 0; i < this.releasedMouse; i++) {
	    if (this.mouseReleased[i] == button) {
		return true;
	    }
	}

	return false;
    }

    public boolean[] getMouseDown() {
	return this.mouseDown;
    }

    @Override
    public boolean isMouseDown(int button) {
	return this.mouseDown[button];
    }

    @Override
    public int getKeyPressed() {
	return (this.pressedKey > 0) ? this.keyPressed[0] : BaseInput.NO_KEY;
    }

    @Override
    public boolean isKeyPressed(int keyCode) {
	for (int i = 0; i < this.pressedKey; i++) {
	    if (this.keyPressed[i] == keyCode) {
		return true;
	    }
	}
	return false;
    }

    @Override
    public int getKeyReleased() {
	return (this.releasedKey > 0) ? this.keyReleased[0] : BaseInput.NO_KEY;
    }

    @Override
    public boolean isKeyReleased(int keyCode) {
	for (int i = 0; i < this.releasedKey; i++) {
	    if (this.keyReleased[i] == keyCode) {
		return true;
	    }
	}
	return false;
    }

    public boolean[] getKeyDown() {
	return this.keyDown;
    }

    @Override
    public boolean isKeyDown(int keyCode) {
	return this.keyDown[keyCode & 0xFF];
    }

    @Override
    public int getKeyTyped() {
	return this.keyTyped.getKeyTyped();
    }

    @Override
    public boolean isKeyTyped(int keyCode) {
	return this.keyTyped.isKeyTyped(keyCode);
    }

    @Override
    public long getRepeatDelay() {
	return this.keyTyped.getRepeatDelay();
    }

    @Override
    public void setRepeatDelay(long delay) {
	this.keyTyped.setRepeatDelay(delay);
    }

    @Override
    public long getRepeatRate() {
	return this.keyTyped.getRepeatRate();
    }

    @Override
    public void setRepeatRate(long rate) {
	this.keyTyped.setRepeatRate(rate);
    }

    public Component getComponent() {
	return this.component;
    }

    protected class InputListener implements KeyListener, MouseListener,
	    MouseMotionListener, FocusListener {
	@Override
	public void keyPressed(KeyEvent e) {
	    // we must check is the key is being pressed or not
	    // since this event is repetitively called when a key is pressed
	    if (!AWTInput.this.keyDown[e.getKeyCode() & 0xFF]) {
		AWTInput.this.keyDown[e.getKeyCode() & 0xFF] = true;
		AWTInput.this.keyPressed[AWTInput.this.pressedKey] = e
			.getKeyCode();
		AWTInput.this.pressedKey++;
	    }
	    e.consume();
	}

	@Override
	public void keyReleased(KeyEvent e) {
	    AWTInput.this.keyDown[e.getKeyCode() & 0xFF] = false;
	    AWTInput.this.keyReleased[AWTInput.this.releasedKey] = e
		    .getKeyCode();
	    AWTInput.this.releasedKey++;
	    e.consume();
	}

	@Override
	public void keyTyped(KeyEvent e) {
	    e.consume();
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {
	    AWTInput.this.mouseExists = true;
	}

	@Override
	public void mouseExited(MouseEvent e) {
	    AWTInput.this.mouseExists = false;
	    for (int i = 0; i < 4; i++) {
		AWTInput.this.mouseDown[i] = false;
	    }
	}

	@Override
	public void mousePressed(MouseEvent e) {
	    AWTInput.this.mouseDown[e.getButton()] = true;

	    AWTInput.this.mousePressed[AWTInput.this.pressedMouse] = e
		    .getButton();
	    AWTInput.this.pressedMouse++;
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	    AWTInput.this.mouseDown[e.getButton()] = false;
	    AWTInput.this.mouseReleased[AWTInput.this.releasedMouse] = e
		    .getButton();
	    AWTInput.this.releasedMouse++;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
	    AWTInput.this.mouseX = e.getX();
	    AWTInput.this.mouseY = e.getY();
	}

	@Override
	public void mouseMoved(MouseEvent e) {
	    AWTInput.this.mouseX = e.getX();
	    AWTInput.this.mouseY = e.getY();
	}

	@Override
	public void focusGained(FocusEvent e) {

	}

	@Override
	public void focusLost(FocusEvent e) {
	    AWTInput.this.refresh();
	}
    }
}
