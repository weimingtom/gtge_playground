===============
GTGE NETWORKING
===============

Website : http://www.goldenstudios.or.id/
Source  : http://gtge.googlecode.com/
License : LGPL (see LICENSE.txt and LICENSE.LESSER.txt)


-----------
What is it?
-----------

GTGE Networking is networking support for GTGE for making networked multiplayer game.



------------
Requirements
------------

- Desktop System
- Java 2 Standard Edition (J2SE) version 1.4 or later



------------------
The Latest Version
------------------

The latest version of GTGE can be found at GTGE official website:
http://www.goldenstudios.or.id/



# Thank you for using GTGE Networking Frame Work #

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Copyright � 2003-2008 Golden T Studios
http://www.goldenstudios.or.id/
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

















